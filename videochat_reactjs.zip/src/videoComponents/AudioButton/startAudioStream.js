//this functions job is to update all peerConnections (addTracks) and update redux call status

const startAudioStream = (streams) => {
  const localStream = streams.localStream;
  for (const s in streams) {
    //s is the key
    if (s !== "localStream") {
      //we dont add tracks to localStream
      const curStream = streams[s];
      //addTracks to all peerConnections
      localStream.stream.getAudioTracks().forEach((t) => {
        curStream.peerConnection.addTrack(t, streams.localStream.stream);
      });
    }
  }
};

export default startAudioStream;
