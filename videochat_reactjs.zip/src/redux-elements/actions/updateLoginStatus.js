export const setAuthData = (data) => ({
  type: "SET_AUTH_DATA",
  payload: data,
});
