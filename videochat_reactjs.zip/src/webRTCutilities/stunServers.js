let peerConfiguration = {
  iceServers: [
    {
      urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"],
    },
    {
      urls: "turn:relay1.expressturn.com:3478?transport=udp",
      username: "efGNQ6K4YX88O3S6QI",
      credential: "gmlFfbQOjXO8Bc2n",
    },
  ],
};

export default peerConfiguration;
