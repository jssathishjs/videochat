import { compose } from "redux";
import peerConfiguration from "./stunServers";

const createPeerConnection = (addIce) => {
  return new Promise(async (resolve, reject) => {
    const peerConnection = new RTCPeerConnection(peerConfiguration);
    //rtcpeerconnection  is the connection to the peer
    // we may need more than one this time
    //we pass it to config object, which is just stun servers
    //it will get us ice candidates
    const remoteStream = new MediaStream();
    peerConnection.addEventListener("signalingstatechange", (e) => {
      console.log("signaling state change");
      console.log(e);
    });

    peerConnection.addEventListener("track", (e) => {
      console.log("got a track from remote...");
      console.log(e.streams[0].getTracks());
      e.streams[0].getTracks().forEach((track) => {
        remoteStream.addTrack(track, remoteStream);
        console.log("fingers crossed...");
      });
    });

    peerConnection.addEventListener("icecandidate", (e) => {
      console.log("found ice candidate...");
      if (e.candidate) {
        addIce(e.candidate);
      } else {
        console.log(`<>e.candidate missing <> ${e.candidate}`);
      }
    });
    resolve({
      peerConnection,
      remoteStream,
    });
  });
};

export default createPeerConnection;
