const { MongoClient } = require("mongodb");
const config = require("./config.json");
//const logger = require("../logger");

const client = new MongoClient(config.mongoURI);

async function connect() {
  try {
    await client.connect();
    console.log("Connected to MongoDB");
    // logger.log({
    //   level: "info",
    //   message: `Connected to MongoDB`,
    // });
    return client.db();
  } catch (error) {
    console.error("Error connecting to MongoDB", error);
    // logger.log({
    //   level: "info",
    //   message: error,
    // });
    throw error;
  }
}

module.exports = { connect };
