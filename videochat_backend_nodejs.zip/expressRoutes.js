//this is where all our express stuff happens (Routes)

const app = require("./server").app;
const jwt = require("jsonwebtoken");
const linkSecret = "leicestershire";
const { v4: uuidv4 } = require("uuid");
const { config } = require("./server");
const axios = require("axios");
const { saveData, getData, saveAptData, getAptData } = require("./dbActions");

//normally this would be persistant data... From API, File, DB...etc
//need to think  whether we really need to bring the Call Details from DB...
let professionalAppointments = [
  // {
  //   toJid: "prof_vitacapegmailcom@chat.vitacape.com",
  //   fromJid: "vitagistgmailcom@chat.vitacape.com",
  //   apptDate: Date.now() + 500000,
  //   uuid: uuidv4(),
  //   clientName: "Warren Buffet",
  // },
];
app.set("professionalAppointments", professionalAppointments);

app.get("/api/v1/test", (req, res) => {
  res.json({ status: "Test route.." });
});
//this route is for US! in production, a receptionanist, or calendar scheduling app
//would send this out. we will print it out and paste it in. it will drop
//us on our React site with the right info for CLIENT1 to make an  offer
app.get("/api/v1/user-link", (req, res) => {
  const appData = professionalAppointments[0];
  const dupStatus = isDuplicateCall(appData);
  if (!dupStatus) {
    professionalAppointments.push(appData);
    app.set("professionalAppointments", professionalAppointments);
  }
  //we  need to encode this data in a token
  //so it can be added to the url
  const token = jwt.sign(appData, linkSecret);
  // res.send(`https://localhost:3000/join-video?token=${token}`);
  res.send(`https://localhost:3000/join-video?token=${token}`);
});

const isDuplicateCall = (appData) => {
  const arr = professionalAppointments.find(
    (ap) => ap.toJid === appData.toJid && ap.fromJid === appData.fromJid
  );
  if (arr) {
    return true;
  } else {
    return false;
  }
};

app.get("/api/v1/chatuser-queue", (req, res) => {
  try {
    if (!req.query.tojid) {
      res.status(400).json({ msg: "Pleaae send toJid as Query string" });
    } else if (req.query.toJid === "") {
      res.status(400).json({ msg: "Pleaae send toJid as Query string" });
    } else {
      getData(req.query.tojid)
        .then((data) => {
          res.status(200).json(data);
        })
        .catch((error) => {
          console.log(error);
          res.status(400).json({ msg: error });
        });
    }
  } catch (error) {
    console.log(error);
    res
      .status(400)
      .json({ msg: "Something went wrong, Please try again later" });
  }
});

const checkAuthorization = async (data) => {
  return new Promise((resolve, reject) => {
    let chatServer = "";
    let apiAuthServer = "";
    if (config.env === "production") {
      chatServer = config.prodchatserver;
      apiAuthServer = config.prodauthserver;
    } else {
      chatServer = config.devchatserver;
      apiAuthServer = config.devauthserver;
    }
    try {
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: `${apiAuthServer}/consumer/xmpplogin`,
        headers: {
          "Content-Type": "application/json",
        },
        data: data,
      };
      axios.request(config).then((response) => {
        resolve(response.data);
      });
    } catch (error) {
      console.log(error);
      resolve(false);
    }
  });
};

app.post("/api/v1/chatuser-link", async (req, res) => {
  let chatServer = "";
  let apiAuthServer = "";
  if (config.env === "production") {
    chatServer = config.prodchatserver;
    apiAuthServer = config.prodauthserver;
  } else {
    chatServer = config.devchatserver;
    apiAuthServer = config.devauthserver;
  }
  // {
  //   token: "",
  //   fromJid: "",
  //   fullName: "",
  //   toJid: ""
  // }
  let appData = req.body;
  if (
    !req.body.token ||
    !req.body.fromJid ||
    !req.body.fullName ||
    !req.body.toJid
  ) {
    res.status(400).json({ msg: "Required parameters missing." });
  } else {
    let data = JSON.stringify({
      username: "sa",
      password: req.body.token,
    });
    const authStatus = await checkAuthorization(data);
    if (authStatus) {
      appData = {
        uuid: `${appData.fromJid}_${appData.toJid}`,
        fromJid: `${
          appData.fromJid.indexOf("@") === -1
            ? appData.fromJid + "@" + chatServer
            : appData.fromJid
        }`,
        clientName: appData.fullName,
        toJid: `${
          appData.toJid.indexOf("@") === -1
            ? appData.toJid + "@" + chatServer
            : appData.toJid
        }`,
        apptDate: Date.now(),
        waiting: false,
      };
      console.log(appData);
      console.log("<< Outside >>");
      professionalAppointments = app.get("professionalAppointments");
      const dupStatus = isDuplicateCall(appData);
      if (!dupStatus) {
        professionalAppointments.push(appData);
        app.set("professionalAppointments", professionalAppointments);
        // const save = async () => {
        //   const status = await saveAptData(appData);
        //   return status;
        // };
        // try {
        saveAptData(appData)
          .then((saveStatus) => {
            console.log(saveStatus);
          })
          .catch((error) => {
            console.log(error);
          });

        // } catch (error) {
        //   console.log(error)
        // }

        //save data to a in-memory db

        // saveData(appData)
        //   .then((data) => {
        //     console.log(data);
        //   })
        //   .catch((error) => {
        //     console.log(error);
        //   });
        console.log(app.get("professionalAppointments"));
        console.log("----- pushed new App Data -----");
      }
      //we  need to encode this data in a token
      //so it can be added to the url
      const token = jwt.sign(appData, linkSecret);
      // res.send(`https://localhost:3000/join-video?token=${token}`);
      res.send(`/join-video?token=${token}`);
    } else {
      res.status(401).json({ msg: "Unauthorized Access" });
    }
  }
});

app.post("/api/v1/validate-link", (req, res) => {
  const token = req.body.token;
  console.log(token);
  // verify a token symmetric - synchronous
  const decodedData = jwt.verify(token, linkSecret);
  //console.log(professionalAppointments);
  res.json(decodedData);
});

// app.post("/api/v1/chatuser-queue", (req, res) => {
//   const token = req.body.token;
//   console.log(token);
//   // verify a token symmetric - synchronous
//   const decodedData = jwt.verify(token, linkSecret);
//   //console.log(professionalAppointments);
//   res.json(decodedData);
// });

app.get("/api/v1/pro-link", (req, res) => {
  const authToken =
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOiI5RjNCOTNDMTE3NkNFRTlBIiwiYWRtaW4iOmZhbHNlLCJwbGFuIjoibGF1ZGl0b3IiLCJyb2xlIjoiU1UiLCJuYW1lIjoiU2F0aGlzaCIsInVzZXJfaWQiOiI2M2ZkOGE3YTM4NzQ1OWQ1YmZjOWQ1NDQiLCJleHAiOjE3MDUzNTIwNzJ9.-yTOVmeONK5bKXHmpPixBYMFNQkBvK3ZDP-U03J3gHQ";
  const userData = {
    fullName: "Sathish.JS",
    apptDate: Date.now() + 500000,
    proId: "abcde-12345-123",
    fromJid: "prof_vitacapegmailcom@chat.vitacape.com",
    toJid: "vitagistgmailcom@chat.vitacape.com",
  };
  const token = jwt.sign(userData, linkSecret);
  res.send(
    `<a href="https://localhost:3000/dashboard?token=${token}&authtoken=${authToken}" target="_blank">Link here</a>`
  );
});

app.post("/api/v1/clientpro-link", (req, res) => {
  let chatServer = "";
  let chatUiServer = "";
  if (config.env === "production") {
    chatServer = config.prodchatserver;
    chatUiServer = config.prodchatuiserver;
  } else {
    chatServer = config.devchatserver;
    chatUiServer = config.devchatuiserver;
  }
  // const userData = {
  //   fullName: "Sathish.JS",
  //   apptDate: Date.now() + 500000,
  //   clientName: "Sayali",
  //   proId: 1234,
  // };
  let appData = req.body;
  if (
    !req.body.token ||
    !req.body.fullName ||
    !req.body.toJid ||
    !req.body.proId
  ) {
    res.status(400).json({ msg: "Required parameters missing." });
  } else {
    appData = {
      token: appData.token,
      fullName: appData.fullName,
      toJid: `${
        appData.toJid.indexOf("@") === -1
          ? appData.toJid + "@" + chatServer
          : appData.toJid
      }`,
      proId: `${
        appData.proId.indexOf("@") === -1
          ? appData.proId + "@" + chatServer
          : appData.proId
      }`,
    };

    const token = jwt.sign(appData, linkSecret);
    // res.send(
    //   `<a href="${chatUiServer}/dashboard?token=${token}&authtoken=${req.body.token}" target="_blank">Link here</a>`
    // );
    res.send(`/dashboard?token=${token}&authtoken=${req.body.token}`);
  }
});

app.post("/api/v1/clientpro-link2", (req, res) => {
  try {
    let chatServer = "";
    if (config.env === "production") {
      chatServer = config.prodchatserver;
    } else {
      chatServer = config.devchatserver;
    }
    // const userData = {
    //   fullName: "Sathish.JS",
    //   apptDate: Date.now() + 500000,
    //   clientName: "Sayali",
    //   proId: 1234,
    // };
    let appData = req.body;
    if (
      !req.body.token ||
      !req.body.fromJid ||
      !req.body.fullName ||
      // !req.body.clientName ||
      !req.body.toJid
    ) {
      //console.log(appData);
      res.status(400).json({ msg: "Required parameters missing." });
    } else {
      appData = {
        token: appData.token,
        fromJid: `${
          appData.fromJid.indexOf("@") === -1
            ? appData.fromJid + "@" + chatServer
            : appData.fromJid
        }`,
        fullName: appData.fullName,
        toJid: `${
          appData.toJid.indexOf("@") === -1
            ? appData.toJid + "@" + chatServer
            : appData.toJid
        }`,
        proId: `${
          appData.fromJid.indexOf("@") === -1
            ? appData.fromJid + "@" + chatServer
            : appData.fromJid
        }`,
      };

      const token = jwt.sign(appData, linkSecret);
      res.status(200).json({ token: token });
    }
  } catch (error) {
    console.log(error);
    res
      .status(400)
      .json({ msg: "Something went wrong, please try again later" });
  }
});
