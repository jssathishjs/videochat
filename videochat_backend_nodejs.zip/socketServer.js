//all our socket stuffs happens here

const io = require("./server").io;
const app = require("./server").app;
const linkSecret = "leicestershire";
const jwt = require("jsonwebtoken");
const {
  saveData,
  saveAptData,
  deleteAptData,
  getAptData,
} = require("./dbActions");

// const professionalAppointments = app.get("professionalAppointments");
const connectedProfessionals = [];
const connectedClients = [];

const allKnownOffers = {
  //uniqueId - key
  //offer
  //professionalsFullName
  //clientName
  //apptDate
  //offererIceCandidates
  //answer
  //answerIceCandidates
};

io.on("connection", (socket) => {
  // console.log(`${socket.id} has connected`);

  //to fill in later
  const handShakeData = socket.handshake.auth.jwt;
  let decodedData;
  try {
    decodedData = jwt.verify(handShakeData, linkSecret);
  } catch (error) {
    console.log(error);
    //these are not the droids we are looking for
    //goodbye
    socket.disconnect();
    return;
  }

  // console.log(`##### Decoded Data #####ç`);
  // console.log(decodedData);

  const { fullName, proId, toJid } = decodedData;

  if (proId) {
    //this is a professional, update/add to connectedProfessionals
    //check to see if this user is already  in connectedProfessionals
    //this would happen because they have reconnected
    // console.log(` --------- Connected Profesionals --------`);
    // console.log(connectedProfessionals);
    const connectedPro = connectedProfessionals.find(
      (cp) => cp.proId === proId
    );

    if (connectedPro) {
      //if they are then just update the new socket id
      connectedPro.socketId = socket.id;
    } else {
      console.log(`<> Adding connected Professionals <>`);
      console.log(proId);
      //the below code is a hack as there is unwanted value getting added
      if (proId.indexOf("vitacape.com") !== -1) {
        connectedProfessionals.push({
          socketId: socket.id,
          fullName,
          proId,
          toJid,
        });
      }
    }

    const getApts = async () => {};
    //send the appt Data out to the professional
    const professionalAppointments = app.get("professionalAppointments");
    // console.log(`-@-@-@-@ from ${fromJid} and to ${toJid}`);

    socket.emit(
      "apptData",
      professionalAppointments.filter(
        // (pa) => pa.professionalsFullName === fullName
        (pa) =>
          // (pa.fromJid === fromJid && pa.toJid === toJid) ||
          // (pa.fromJid === toJid && pa.toJid === fromJid)
          pa.fromJid === toJid
        // (pa) => pa.toJid === toJid
      )
    );
    // console.log(professionalAppointments);
    // console.log("---- begin ---");
    let temp = professionalAppointments.filter(
      // (pa) => pa.professionalsFullName === fullName
      (pa) => pa.fromJid === toJid
      // (pa.fromJid === fromJid && pa.toJid === toJid) ||
      // (pa.fromJid === toJid && pa.toJid === fromJid)
    );
    // console.log(temp);
    // console.log("---- end ---");
    //loop through all the known offers and send out to the professional that just joined
    //the ones that belong to him/her
    for (const key in allKnownOffers) {
      // if (allKnownOffers[key].professionalsFullName === fullName) {
      if (
        allKnownOffers[key].fromJid === toJid
        // (allKnownOffers[key].fromJid === fromJid &&
        //   allKnownOffers[key].toJid === toJid) ||
        // (allKnownOffers[key].fromJid === toJid &&
        //   allKnownOffers[key].toJid === fromJid)
      ) {
        //this offer is for this pro
        io.to(socket.id).emit("newOfferWaiting", allKnownOffers[key]);
      }
    }
  } else {
    //this is a client
    const { uuid, clientName, fromJid, toJid } = decodedData;
    //check to see if client is already in the Array
    //why? could have reconnected
    const clientExist = connectedClients.find((c) => c.uuid === uuid);

    if (clientExist) {
      //already connected, just update the id
      clientExist.socketId = socket.id;
    } else {
      //add them
      connectedClients.push({
        clientName,
        uuid,
        socketId: socket.id,
        fromJid,
        toJid,
      });
    }
    const offerForThisClient = allKnownOffers[uuid];
    if (offerForThisClient) {
      socket.to(socket.id).emit("answerToClient", offerForThisClient.answer);
    }
  }
  // console.log(connectedProfessionals);

  socket.on("newAnswer", ({ answer, uuid }) => {
    //emit this to the client
    const socketToSendTo = connectedClients.find((c) => c.uuid === uuid);
    if (socketToSendTo) {
      socket.to(socketToSendTo.socketId).emit("answerToClient", answer);
    }
    const knownOffer = allKnownOffers[uuid];
    if (knownOffer) {
      knownOffer.answer = answer;
    }
  });

  socket.on("newOffer", async ({ offer, apptInfo }) => {
    //offer = sdp/type, apptInfo has the uuid that we can add to allKnownOffers
    //so that, the professional can find EXACTLY the right allKnownOffers
    console.log("new Offer->->");
    allKnownOffers[apptInfo.uuid] = {
      ...apptInfo,
      offer,
      offererIceCandidates: [],
      answer: null,
      answerIceCandidates: [],
    };
    //we dont emit this to everyone like we did for chatserver
    //we only want this to go to professional
    //we get professional appointments from express (that's where it's made)
    //#SATHIKUM the code need to changes here
    const professionalAppointments = app.get("professionalAppointments");
    //find this particular appt so we can update that the user is waiting (has sent us an offer)
    console.log(" &*&* New Offer ----->");
    console.log(`apptInfo.uuid = ${apptInfo.toJid}`);
    console.log(professionalAppointments);
    // const pa = professionalAppointments.find((pa) => pa.uuid === apptInfo.uuid);

    const pa = professionalAppointments.filter(
      (pa) => pa.toJid === apptInfo.toJid
    );
    console.log(`----> pa <-----`);

    if (pa) {
      for (let i = 0; i < pa.length; i++) {
        pa[i].waiting = true;
        const jsonData = {
          toJid: pa[i].toJid,
          fromJid: pa[i].fromJid,
          uuid: pa[i].uuid,
          clientName: pa[i].clientName,
          waiting: pa[i].waiting,
          apptDate: pa[i].apptDate,
        };
        saveData(jsonData)
          .then((status) => {
            console.log(status);
          })
          .catch((error) => {
            console.log(error);
          });
        // const save = async () => {
        //   const status = await saveAptData(jsonData);
        //   return status;
        // };
        // const saveStatus = save();
      }
    } else {
      console.log(`"Waiting is set to false" ${apptInfo.uuid}`);
      console.log(professionalAppointments);
    }
    console.log(pa);

    //find  this particular  professional so we can emit
    console.log(">--- connected Professionals ------>");
    console.log(connectedProfessionals);
    const p = connectedProfessionals.find(
      // (cp) => (cp.fullName = apptInfo.professionalsFullName)
      // (cp) => cp.fromJid === apptInfo.fromJid && cp.toJid === apptInfo.toJid
      (cp) => cp.toJid === apptInfo.toJid
    );

    if (p) {
      //only emit  if professional is connected
      const socketId = p.socketId;
      console.log(`Emitting to socketId => ${socketId}`);
      //send the new offer over
      socket
        .to(socketId)
        .emit("newOfferWaiting", allKnownOffers[apptInfo.uuid]);
      //send the updated appts info with the  new waiting
      const proData = professionalAppointments.filter(
        // (pa) => pa.professionalsFullName === apptInfo.professionalsFullName
        // (pa) => pa.fromJid === apptInfo.fromJid && pa.toJid === apptInfo.toJid
        (pa) => pa.toJid === apptInfo.toJid
      );
      console.log(`> Emitting Data < -> ${socketId}`);
      console.log(proData);
      socket.to(socketId).emit("apptData", proData);
    }
  });

  socket.on("getIce", (uuid, who, ackFunc) => {
    console.log(`getIce -> allknownoffers ->`);
    console.log(allKnownOffers);
    const offer = allKnownOffers[uuid];
    console.log(offer); //to be tested, seems to be not working #SATHIKUM
    let iceCandidates = [];
    if (offer) {
      if (who === "professional") {
        iceCandidates = offer.offererIceCandidates;
      } else if (who === "client") {
        iceCandidates = offer.answerIceCandidates;
      }
      ackFunc(iceCandidates);
    }
  });

  //Disconnect when call is hanged-up or disconnect call
  socket.on("disConnect", async ({ who, fromJid, toJid }) => {
    // let professionalAppointments = app.get("professionalAppointments");
    if (who === "professional" || who === "client") {
      console.log(` < Disconnect > from ${fromJid} to ${toJid}`);

      //Delete DB Call here
      const profAp = await deleteAptData(toJid, fromJid);
      console.log(profAp);
      const professionalAppointments = profAp.data;

      // const delApt = professionalAppointments.filter(
      //   (pa) => pa.toJid === toJid && pa.fromJid === fromJid
      // );
      // for (let i = 0; i < delApt.length; i++) {
      //   delApt[i].waiting = false;
      // }
      app.set("professionalAppointments", professionalAppointments);
      const pa = professionalAppointments.filter(
        (pa) => pa.toJid !== toJid && pa.fromJid !== fromJid
      );
      //app.set("professionalAppointments", pa);
      console.log(`<- Post App set value ->`);
      console.log(app.get("professionalAppointments"));

      // const connectedPro = connectedProfessionals.filter((cp) => {
      //   cp.proId === toJid;
      // });
      const connectedPro = connectedProfessionals.find(
        (cp) => cp.proId === toJid
      );
      if (connectedPro) {
        const socketId = connectedPro.socketId;
        console.log(`Emitting apptData post disconnect to ${socketId}`);
        console.log(connectedPro);

        io.to(socketId).emit("apptData", pa);
      }

      const connectedPro2 = connectedProfessionals.find(
        (cp) => cp.proId === fromJid
      );
      if (connectedPro2) {
        const socketId = connectedPro2.socketId;
        console.log(`Emitting apptData post disconnect to ${socketId}`);
        console.log(connectedPro2);

        io.to(socketId).emit("apptData", pa);
      }
      // console.log(pa);

      //socket.emit("apptData", pa);
      // console.log(cp);
    } else {
      //to be coded
      console.log(`<=== Disconnect Called ===>`);
      console.log(`who = ${who} fromJid = ${fromJid} toJid = ${toJid}`);
    }
  });

  socket.on("iceToServer", ({ who, iceC, uuid }) => {
    console.log("iceToServer ========================", who);

    const offerToUpdate = allKnownOffers[uuid];
    if (offerToUpdate) {
      if (who === "client") {
        //this means the client has sent a iceC
        //update the offer
        offerToUpdate.offererIceCandidates.push(iceC);
        const socketToSendTo = connectedProfessionals.find(
          (cp) => cp.fromJid === decodedData.toJid
        );
        if (socketToSendTo) {
          socket.to(socketToSendTo.socketId).emit("iceToClient", iceC);
        }
      } else if (who === "professional") {
        offerToUpdate.answerIceCandidates.push(iceC);
        const socketToSendTo = connectedClients.find((cp) => cp.uuid === uuid);
        if (socketToSendTo) {
          socket.to(socketToSendTo.socketId).emit("iceToClient", iceC);
        }
      }
    }
  });
});
