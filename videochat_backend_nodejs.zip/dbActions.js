const { connect } = require("./db");

var Datastore = require("nedb"),
  db = new Datastore();

const getData = (toJid) => {
  return new Promise((resolve, reject) => {
    try {
      db.find(
        { toJid: toJid },
        {
          _id: 0,
          fromJid: 1,
          toJid: 1,
          clientName: 1,
          apptDate: 1,
          waiting: 1,
        },
        function (err, docs) {
          if (err) {
            reject(err);
          } else {
            resolve(docs);
          }
        }
      );
    } catch (error) {
      reject(error);
    }
  });
};

const getAptData = async (toJid) => {
  // const jsonData = req.body;
  if (!toJid) {
    return { error: true, msg: "toJid is required" };
  } else {
    try {
      const db = await connect();
      const collection = db.collection("xmppvideochat");

      //Query to filter based on IN operator
      const dbQuery = { toJid: toJid };
      const fieldList = {
        projection: {
          _id: 0,
          fromJid: 1,
          toJid: 1,
          clientName: 1,
          apptDate: 1,
          waiting: 1,
        },
      };
      const docs = await collection.find(dbQuery, fieldList).toArray();

      return { error: false, data: docs };
    } catch (err) {
      // logger.log({
      //   level: "error",
      //   message: err,
      // });
      return {
        error: true,
        msg: "Something went wrong, please try again later",
      };
    }
  }
};

const getAllAptData = async () => {
  return new Promise(async (resolve, reject) => {
    // const jsonData = req.body;
    try {
      const db = await connect();
      const collection = db.collection("xmppvideochat");

      //Query to filter based on IN operator
      const dbQuery = {};
      const fieldList = {
        projection: {
          _id: 0,
          fromJid: 1,
          toJid: 1,
          clientName: 1,
          apptDate: 1,
          waiting: 1,
        },
      };
      const docs = await collection.find(dbQuery, fieldList).toArray();
      resolve({ error: false, data: docs });
    } catch (err) {
      // logger.log({
      //   level: "error",
      //   message: err,
      // });
      reject({
        error: true,
        msg: "Something went wrong, please try again later",
      });
    }
  });
};

//Delete the Call(s) once call ends between 2 client(s) using toJid and fromJid
//the code is clean and works fine
const deleteAptData = async (toJid, fromJid) => {
  return new Promise(async (resolve, reject) => {
    try {
      // const jsonData = req.body;
      if (!toJid || !fromJid) {
        reject({ error: true, msg: "toJid and fromJid is required" });
      } else {
        const db = await connect();
        const collection = db.collection("xmppvideochat");

        //Query to filter based on IN operator
        const deldbQuery = { toJid, fromJid };

        const deldocs = await collection.deleteMany(deldbQuery);
        console.log(`< Delete Status >`);
        console.log(deldocs);

        const dbQuery = {};
        const fieldList = {
          projection: {
            _id: 0,
            fromJid: 1,
            toJid: 1,
            clientName: 1,
            apptDate: 1,
            waiting: 1,
          },
        };
        const docs = await collection.find(dbQuery, fieldList).toArray();

        resolve({ error: false, data: docs });
      }
    } catch (err) {
      // logger.log({
      //   level: "error",
      //   message: err,
      // });
      reject({
        error: true,
        msg: "Something went wrong, please try again later",
      });
    }
  });
};

const saveAptData = async (jsonData) => {
  return new Promise(async (resolve, reject) => {
    //const jsonData = req.body;
    //console.log(jsonData.uuid);
    console.log("<< Inside >>");
    if (
      jsonData.uuid === "" ||
      jsonData.fromJid === "" ||
      jsonData.toJid === "" ||
      jsonData.apptDate === "" ||
      jsonData.clientName === ""
    ) {
      reject({
        msg: "uuid, fromJid, toJid, apptDate, waiting, and clientName is required",
      });
    } else {
      try {
        const db = await connect();
        const collection = db.collection("xmppvideochat");
        const { fromjid, tojid, count } = jsonData;
        const docs = await collection.find({ fromjid, tojid }).toArray();
        if (docs.length >= 1) {
          await collection.updateOne(
            { toJid: jsonData.toJid, fromJid: jsonData.fromJid },
            {
              $set: {
                waiting: jsonData.waiting,
                apptDate: jsonData.apptDate,
              },
            }
          );
        } else {
          const doc = {
            uuid: jsonData.uuid,
            fromJid: jsonData.fromJid,
            toJid: jsonData.toJid,
            clientName: jsonData.clientName,
            apptDate: jsonData.apptDate,
            waiting: jsonData.waiting,
          };
          await collection.insertOne(doc);
        }
        resolve({ msg: "Updated successfully." });
      } catch (err) {
        // logger.log({
        //   level: "error",
        //   message: err,
        // });
        reject({ msg: "Something went wrong, please try again later" });
      }
    }
  });
};

const saveData = (jsonData) => {
  return new Promise((resolve, reject) => {
    try {
      //         {
      //     uuid: 'yeher32675duitercom_prof_vitacapegmailcom',
      //     fromJid: 'yeher32675duitercom@devchat.vitacape.com',
      //     clientName: 'Warren Buffett',
      //     toJid: 'prof_vitacapegmailcom@devchat.vitacape.com',
      //     apptDate: 1705915519940,
      //     waiting: true
      //   }

      if (
        !jsonData.uuid ||
        !jsonData.fromJid ||
        !jsonData.toJid ||
        !jsonData.apptDate ||
        !jsonData.waiting ||
        !jsonData.clientName
      ) {
      }
      db.find(
        { fromJid: jsonData.fromJid, toJid: jsonData.toJid },
        function (err, docs) {
          if (err) {
            reject(err);
          } else {
            if (docs.length >= 1) {
              db.update(
                { toJid: jsonData.toJid, fromJid: jsonData.fromJid },
                {
                  $set: {
                    waiting: jsonData.waiting,
                    apptDate: jsonData.apptDate,
                  },
                },
                { multi: true },
                function (err, numReplaced) {
                  if (err) {
                    reject(err);
                  } else {
                    resolve(`Updated ${numReplaced} row(s)`);
                  }
                }
              );
              reject("data exists");
            } else {
              //add data to the in-memory DB
              const doc = {
                uuid: jsonData.uuid,
                fromJid: jsonData.fromJid,
                toJid: jsonData.toJid,
                clientName: jsonData.clientName,
                apptDate: jsonData.apptDate,
                waiting: jsonData.waiting,
              };
              db.insert(doc, function (err, newDoc) {
                if (err) {
                  reject(err);
                } else {
                  resolve(newDoc);
                }
              });
            }
          }
        }
      );
    } catch (error) {
      reject(error);
    }
  });
};

module.exports = {
  saveAptData,
  getAptData,
  getAllAptData,
  deleteAptData,
  saveData,
  getData,
};
