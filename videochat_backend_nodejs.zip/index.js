//this is main file which we run with nodemon
require("./socketServer");
require("./expressRoutes");
