//this is where we  create express and socket.io server

const fs = require("fs"); //the file system
const path = require("path");
const http = require("http");
const https = require("https");
const express = require("express");
const cors = require("cors");
const socketio = require("socket.io");
const app = express();
const configPath = path.join(__dirname, "config.json");
// Read the content of config.json
const rawConfig = fs.readFileSync(configPath);
const config = JSON.parse(rawConfig);

app.use(cors()); // this will open our Express API to any domain
app.use(express.static(__dirname + "/public"));
app.use(express.json()); //this will allow to parse JSON in the body with the body parser

//Uncomment for local development
const key = fs.readFileSync("./certs/cert.key");
const cert = fs.readFileSync("./certs/cert.crt");

//Uncomment for local Development
const expressServer = https.createServer({ key, cert }, app);
//comment for local Development
// const expressServer = http.createServer({}, app);
const io = socketio(expressServer, {
  cors: ["https://localhost:3000"],
});

expressServer.listen(config.port);
module.exports = { io, expressServer, app, config };
